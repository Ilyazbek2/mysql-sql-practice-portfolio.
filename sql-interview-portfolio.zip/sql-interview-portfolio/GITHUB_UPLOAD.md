# Publish this project to GitHub

## Option A — GitHub website (no command line)

1. Sign in at https://github.com/new.
2. Create a repository named `mysql-sql-practice-portfolio`.
3. Choose **Public** if you want recruiters to view it; choose **Private** if you prefer.
4. Do not add a README, `.gitignore`, or license during repository creation because those files are already included here.
5. Unzip `sql-interview-portfolio.zip` on your computer.
6. In the new repository, choose **Add file → Upload files** and upload the files and folders *inside* the `sql-interview-portfolio` folder.
7. Commit the upload with a message such as `Add five MySQL SQL practice problems`.

## Option B — Git command line

After creating an empty repository on GitHub, open a terminal in the unzipped `sql-interview-portfolio` folder and run:

```bash
git init
git add .
git commit -m "Add five MySQL SQL practice problems"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/mysql-sql-practice-portfolio.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your GitHub username. If Git asks you to authenticate, follow GitHub's sign-in instructions; do not put a password or access token in this project.

## Before publishing

Run `sql/00_setup.sql` in MySQL Workbench, then execute the five solution files to make sure the project works in your environment. The sample data is fictional.
