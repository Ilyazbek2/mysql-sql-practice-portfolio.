# MySQL SQL Practice Portfolio — 5 Analytical Problems

A small portfolio project demonstrating practical SQL skills with MySQL: joins, aggregate functions, grouping, `HAVING`, scalar subqueries, string-length analysis, and time arithmetic.

> **Database:** MySQL 8.0+  
> **Data:** Synthetic sample data created for this project; it does not represent real users or transactions.

## Project structure

```text
sql-interview-portfolio/
├── README.md
├── .gitignore
├── sql/
│   └── 00_setup.sql          # Creates tables and inserts sample data
├── problems/
│   ├── 01_monthly_product_ratings.sql
│   ├── 02_odd_rental_counts.sql
│   ├── 03_completed_revenue_by_city.sql
│   ├── 04_longest_passenger_names.sql
│   └── 05_school_time_span.sql
└── solutions/
    ├── 01_monthly_product_ratings.sql
    ├── 02_odd_rental_counts.sql
    ├── 03_completed_revenue_by_city.sql
    ├── 04_longest_passenger_names.sql
    └── 05_school_time_span.sql
```

## How to run

1. Open MySQL Workbench or another MySQL client.
2. Run `sql/00_setup.sql` to create the `sql_practice_portfolio` database and load sample records.
3. Run each file in `solutions/` to check the completed query.
4. For practice, try writing a query from the corresponding file in `problems/` before opening the solution.

## Problems and skills demonstrated

### 1. Monthly average product ratings
For every product/month pair with at least one review, return `product_id`, month number (`mth`), and average stars (`avg_stars`) rounded to two decimals.

**Skills:** `JOIN`, `MONTH`, `AVG`, `ROUND`, `GROUP BY`.

### 2. Rooms rented an odd number of times
Return each `room_id` and the number of rentals, named exactly `count`, only where the number of rentals is odd.

**Skills:** `COUNT`, `GROUP BY`, `HAVING`, modulo operator `%`.

### 3. Completed booking revenue by city
Calculate each city's total revenue using only bookings whose status is `completed`; sort highest revenue first.

**Skills:** `JOIN`, `WHERE`, `SUM`, `GROUP BY`, `ORDER BY`.

### 4. Passenger(s) with the longest full name
Return every passenger whose `name` has the greatest number of characters. Spaces, hyphens, and periods count as characters; ties must all be returned.

**Skills:** `CHAR_LENGTH`, `MAX`, subquery.

### 5. Time spent at school from lesson 2 through lesson 4
Calculate the interval from the start of lesson 2 to the end of lesson 4 and return the value in `HH:MM:SS` format under the alias `time`.

**Skills:** `TIMEDIFF`, scalar subqueries, time values.

## Notes on the sample schema

- Reviews are grouped by the month of `reviews.submit_date`. The `orders` table is intentionally not needed for Problem 1 because the requested month is the review submission month.
- Each rental record represents one rental event, so rental frequency is calculated by counting rows in `room_rentals`.
- Revenue is calculated from `bookings.total_price` and only `completed` bookings are included.
- Problem 4 uses `CHAR_LENGTH`, so whitespace and punctuation contribute to the name length.
- For Problem 5, the sample data uses `timepair.id = 2` and `timepair.id = 4` for lessons 2 and 4, respectively, matching the exercise's timetable convention.

## Example result format

The output columns are intentionally named to match the exercise requirements:

| Problem | Output columns |
|---|---|
| 1 | `product_id`, `mth`, `avg_stars` |
| 2 | `room_id`, `count` |
| 3 | `city`, `total_revenue` |
| 4 | `name` |
| 5 | `time` |

## GitHub description

**Suggested repository name:** `mysql-sql-practice-portfolio`  
**Suggested description:** `Five practical MySQL analytics exercises covering joins, aggregations, filtering, subqueries, and time calculations.`
