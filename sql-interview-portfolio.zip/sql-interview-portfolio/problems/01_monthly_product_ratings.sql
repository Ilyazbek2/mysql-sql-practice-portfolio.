-- PROBLEM 1: Monthly average product ratings
-- For each (product, month) pair that has reviews, return:
-- product_id, mth (month number), avg_stars (average rating rounded to 2 decimals).
-- Use the review submission date to determine the month.

-- Write your SELECT query below.
