-- PROBLEM 2: Rooms rented an odd number of times
-- Return room_id and the number of rental events, using the exact alias `count`.
-- Only include rooms whose rental count is odd.

-- Write your SELECT query below.
