-- PROBLEM 3: Completed booking revenue by city
-- Return city and total_revenue from completed bookings only.
-- Sort total_revenue in descending order.

-- Write your SELECT query below.
