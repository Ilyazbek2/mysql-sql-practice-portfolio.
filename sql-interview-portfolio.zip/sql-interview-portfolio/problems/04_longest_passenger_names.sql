-- PROBLEM 4: Passenger(s) with the longest full name
-- Return name for every passenger whose name has the maximum character length.
-- Spaces, hyphens, and periods count as characters. Return ties too.

-- Write your SELECT query below.
