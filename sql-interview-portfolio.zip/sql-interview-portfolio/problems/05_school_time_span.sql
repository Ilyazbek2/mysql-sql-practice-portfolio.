-- PROBLEM 5: Time spent at school from lesson 2 through lesson 4
-- Return one column named `time`, formatted HH:MM:SS.
-- Calculate the interval from the start of lesson 2 to the end of lesson 4.
-- In this sample schema, timepair.id 2 and 4 represent lesson 2 and lesson 4.

-- Write your SELECT query below.
