-- PROBLEM 1: Monthly average product ratings
SELECT
    p.product_id,
    MONTH(r.submit_date) AS mth,
    ROUND(AVG(r.stars), 2) AS avg_stars
FROM products AS p
INNER JOIN reviews AS r
    ON r.product_id = p.product_id
GROUP BY
    p.product_id,
    MONTH(r.submit_date)
ORDER BY
    p.product_id,
    mth;
