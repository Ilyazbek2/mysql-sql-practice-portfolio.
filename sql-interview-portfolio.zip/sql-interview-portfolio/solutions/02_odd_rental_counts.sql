-- PROBLEM 2: Rooms rented an odd number of times
SELECT
    room_id,
    COUNT(*) AS count
FROM room_rentals
GROUP BY room_id
HAVING COUNT(*) % 2 = 1
ORDER BY room_id;
