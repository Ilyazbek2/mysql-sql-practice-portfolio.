-- PROBLEM 3: Completed booking revenue by city
SELECT
    p.city,
    SUM(b.total_price) AS total_revenue
FROM bookings AS b
INNER JOIN properties AS p
    ON p.property_id = b.property_id
WHERE b.status = 'completed'
GROUP BY p.city
ORDER BY total_revenue DESC;
