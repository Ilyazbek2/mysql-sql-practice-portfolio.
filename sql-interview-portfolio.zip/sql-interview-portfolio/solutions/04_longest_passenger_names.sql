-- PROBLEM 4: Passenger(s) with the longest full name
SELECT name
FROM passengers
WHERE CHAR_LENGTH(name) = (
    SELECT MAX(CHAR_LENGTH(name))
    FROM passengers
)
ORDER BY name;
