-- PROBLEM 5: Time spent at school from lesson 2 through lesson 4
SELECT TIMEDIFF(
    (SELECT end_pair FROM timepair WHERE id = 4),
    (SELECT start_pair FROM timepair WHERE id = 2)
) AS `time`;
