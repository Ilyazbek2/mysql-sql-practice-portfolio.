-- MySQL 8.0+ setup script for the SQL Practice Portfolio.
-- All records below are fictional sample data.

CREATE DATABASE IF NOT EXISTS sql_practice_portfolio;
USE sql_practice_portfolio;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS room_rentals;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS properties;
DROP TABLE IF EXISTS passengers;
DROP TABLE IF EXISTS timepair;
SET FOREIGN_KEY_CHECKS = 1;

-- Problem 1: Products and reviews
CREATE TABLE products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100) NOT NULL,
    category VARCHAR(60),
    price DECIMAL(10, 2) NOT NULL
);

CREATE TABLE reviews (
    review_id INT PRIMARY KEY,
    product_id INT NOT NULL,
    user_id INT NOT NULL,
    submit_date DATE NOT NULL,
    stars TINYINT NOT NULL,
    CONSTRAINT chk_review_stars CHECK (stars BETWEEN 1 AND 5),
    CONSTRAINT fk_reviews_product FOREIGN KEY (product_id)
        REFERENCES products(product_id)
);

INSERT INTO products (product_id, product_name, category, price) VALUES
(1, 'Mechanical Keyboard', 'Accessories', 79.99),
(2, 'Wireless Mouse', 'Accessories', 29.99),
(3, 'USB-C Hub', 'Electronics', 49.50),
(4, 'Laptop Stand', 'Accessories', 35.00);

INSERT INTO reviews (review_id, product_id, user_id, submit_date, stars) VALUES
(1, 1, 101, '2026-01-05', 5),
(2, 1, 102, '2026-01-18', 4),
(3, 1, 103, '2026-02-02', 3),
(4, 1, 104, '2026-02-16', 4),
(5, 2, 101, '2026-01-09', 3),
(6, 2, 105, '2026-01-22', 4),
(7, 2, 106, '2026-03-12', 5),
(8, 2, 107, '2026-03-20', 5),
(9, 3, 108, '2026-02-04', 4),
(10, 3, 109, '2026-02-25', 2),
(11, 3, 110, '2026-04-01', 5);

-- Problem 2: One row represents one room-rental event
CREATE TABLE room_rentals (
    rental_id INT PRIMARY KEY,
    room_id INT NOT NULL,
    renter_name VARCHAR(100) NOT NULL,
    rental_date DATE NOT NULL
);

INSERT INTO room_rentals (rental_id, room_id, renter_name, rental_date) VALUES
(1, 101, 'Alex', '2026-01-03'),
(2, 101, 'Mira', '2026-01-10'),
(3, 101, 'Sam', '2026-02-01'),
(4, 102, 'Luca', '2026-01-05'),
(5, 102, 'Nora', '2026-02-05'),
(6, 103, 'Ivan', '2026-02-11'),
(7, 104, 'Sara', '2026-01-07'),
(8, 104, 'Ali', '2026-01-18'),
(9, 104, 'Eva', '2026-02-12'),
(10, 104, 'Omar', '2026-03-02'),
(11, 105, 'Aida', '2026-01-08'),
(12, 105, 'Niko', '2026-01-21'),
(13, 105, 'Maks', '2026-02-09'),
(14, 105, 'Lena', '2026-03-14'),
(15, 105, 'Timur', '2026-04-10');

-- Problem 3: Properties and bookings
CREATE TABLE properties (
    property_id INT PRIMARY KEY,
    property_name VARCHAR(120) NOT NULL,
    city VARCHAR(80) NOT NULL
);

CREATE TABLE bookings (
    booking_id INT PRIMARY KEY,
    property_id INT NOT NULL,
    status ENUM('pending', 'confirmed', 'completed', 'cancelled') NOT NULL,
    total_price DECIMAL(10, 2) NOT NULL,
    booking_date DATE NOT NULL,
    CONSTRAINT fk_bookings_property FOREIGN KEY (property_id)
        REFERENCES properties(property_id)
);

INSERT INTO properties (property_id, property_name, city) VALUES
(1, 'Central Apartment', 'Rome'),
(2, 'Navigli Studio', 'Milan'),
(3, 'Seaside Flat', 'Naples'),
(4, 'Trastevere Loft', 'Rome'),
(5, 'Porta Nuova Room', 'Milan'),
(6, 'Old Town House', 'Turin');

INSERT INTO bookings (booking_id, property_id, status, total_price, booking_date) VALUES
(1, 1, 'completed', 250.00, '2026-01-05'),
(2, 1, 'completed', 150.00, '2026-01-12'),
(3, 1, 'cancelled', 500.00, '2026-01-19'),
(4, 2, 'completed', 300.00, '2026-02-03'),
(5, 2, 'pending', 900.00, '2026-02-10'),
(6, 3, 'completed', 180.00, '2026-02-15'),
(7, 4, 'completed', 400.00, '2026-03-01'),
(8, 5, 'completed', 200.00, '2026-03-08'),
(9, 6, 'cancelled', 275.00, '2026-03-15');

-- Problem 4: Passengers (spaces and punctuation are part of name)
CREATE TABLE passengers (
    passenger_id INT PRIMARY KEY,
    name VARCHAR(150) NOT NULL
);

INSERT INTO passengers (passenger_id, name) VALUES
(1, 'Aida Omurbekova'),
(2, 'Jean-Pierre Martin'),
(3, 'Alexander Montgomery-Smith'),
(4, 'Maria de la Cruz'),
(5, 'Dr. Sam Taylor'),
(6, 'Nurbek T. Abdiev'),
(7, 'Alexander Montgomery-Smith');

-- Problem 5: Lesson periods; IDs 2 and 4 represent the second and fourth lessons
CREATE TABLE timepair (
    id INT PRIMARY KEY,
    start_pair TIME NOT NULL,
    end_pair TIME NOT NULL
);

INSERT INTO timepair (id, start_pair, end_pair) VALUES
(1, '08:30:00', '09:15:00'),
(2, '09:20:00', '10:05:00'),
(3, '10:15:00', '11:00:00'),
(4, '11:05:00', '11:50:00'),
(5, '12:50:00', '13:35:00'),
(6, '13:45:00', '14:30:00');
